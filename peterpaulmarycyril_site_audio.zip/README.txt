
Pour mettre en ligne ton site :

1. Va sur https://github.com/peterpaulmarycyril/peterpaulmarycyril.github.io
2. Clique sur "Add file" > "Upload files"
3. Glisse les fichiers :
   - index.html
   - style.css
4. Clique sur "Commit changes"
5. Va dans Settings > Pages et vérifie que la source est bien 'main' et '/'.
6. Ton site sera visible ici : https://peterpaulmarycyril.github.io

Tu peux me redemander de l’aide à tout moment.
