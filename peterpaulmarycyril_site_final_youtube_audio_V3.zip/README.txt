
Site officiel de Peter Paul Mary Cyril
--------------------------------------

Ce site présente le projet musical "Peter Paul Mary Cyril" avec :

- Une section Teaser
- Une section Clips
- Une section Musique avec lecteur audio (via YouTube)

Instructions :

1. Connectez-vous à votre dépôt GitHub Pages :
   https://github.com/peterpaulmarycyril/peterpaulmarycyril.github.io

2. Supprimez les anciens fichiers s'il y en a.

3. Téléversez ces fichiers :
   - index.html
   - style.css
   - README.txt

4. Cliquez sur "Commit changes"

5. Le site sera visible à :
   https://peterpaulmarycyril.github.io
